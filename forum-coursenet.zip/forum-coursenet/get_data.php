<?php
include_once( 'db_connection.php');

$sql = "SELECT * FROM `frm_user`;";

$dbquery = mysqli_query($dbconn, $sql);

if( !$dbquery ){

	$result		= false;
	$message	= mysqli_error();

}else{

	if($dbquery == null ){
		$result		= false;
		$message	= 'No data';
	}else{

		$result = false;
		$datas = array();
		while ($row = mysqli_fetch_array($dbquery)) {

			$datas[] = $row;

			$result = true;
			$message = "Data success";
			
		}
	}
}

$send = array(
	'result' => $result,
	'data' => $datas,
	'message' => $message
);

echo json_encode( $send );

mysqli_close( $dbconn );

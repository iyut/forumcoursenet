<?php

	include_once( 'db_connection.php');

	$txtemail	= $_POST['txtemail'];

	$result = false;
	$field = "";
	$message = "";

	if( empty( $txtemail )){
		$result = false;
		$field = "email";
		$message = "Email is required";
	}else if( !filter_var($txtemail, FILTER_VALIDATE_EMAIL) ){
		$result = false;
		$field = "email";
		$message = "Invalid email format";
	}else{

		$sql = sprintf("SELECT `email`
				FROM `frm_user`
				WHERE `email` = '%s';"
			, $txtemail
		);

		$dbquery = mysqli_query($dbconn, $sql);

		if( !$dbquery ){

			$result		= false;
			$message	= mysqli_error();

		}else{

			if($dbquery == null ){
				$result		= true;
				$field 		= 'email';
				$message	= 'Email is not registered';
			}else{

				$result		= false;
				$field 		= 'email';
				$message	= 'Email ' . $txtemail . ' is registered';
					
				}
			}
		}
	}

	$send = array(
		'result' => $result,
		'field' => $field,
		'message' => $message
	);

	echo json_encode( $send );

	mysqli_close( $dbconn );
/*
INSERT INTO `register` (`id`, `nama`, `email`, `password`) VALUES (NULL, 'Bintoro', 'iyut86@yahoo.com', MD5('test'));
*/

<?php
/*
	$usernamesms = 'j8hcaq';
	$passwordsms = 'kingkongprasejarah';
	$notujuan = '081807556285';
	$isisms = urlencode('Thank you for registering the app');

	$urlsms = sprintf('https://reguler.zenziva.net/apps/smsapi.php?userkey=%s&passkey=%s&nohp=%s&pesan=%s',
			$usernamesms,
			$passwordsms,
			$notujuan,
			$isisms
	);

	file_get_contents($urlsms);
*/
	include_once( 'db_connection.php');

	$txtcomment = $_POST['txtcomment'];
	$txtauthor 	= $_POST['txtauthor'];
	$threadid 	= $_POST['threadid'];

	// default send value
	$result		= false;
	$field 		= '';
	$message	= '';


	if( empty( $txtcomment ) ){

		$result = false;
		$field = "comment";
		$message = "Comment is required";

	}elseif( empty( $threadid ) ){

		$result = false;
		$field = "none";
		$message = "Thread id is required";

	}elseif( empty( $txtauthor ) ){

		$result = false;
		$field = "none";
		$message = "Author email is required";

	}else{

		$sql = sprintf("SELECT *
				FROM `frm_user`
				WHERE `email` = '%s';"
			, $txtauthor
		);

		$dbquery = mysqli_query($dbconn, $sql);

		if( !$dbquery ){

			$result		= false;
			$field 		= 'none';
			$message	= mysqli_error($dbconn);

		}else{

			while ( $row = mysqli_fetch_array( $dbquery ) ) {
		        $id = $row['id'];
		    }

			$sql = sprintf("INSERT INTO `frm_comment` (`thread_id`, `comment`, `author`)
						VALUES ('%s', '%s', '%s');",
						$threadid,
						$txtcomment,
						$id
			);

			$dbquery = mysqli_query($dbconn, $sql);

			if( $dbquery ){

				$result		= true;
				$field 		= 'none';
				$message	= "Your data is saved successfully!";

			}
		}

		

	}

	$send = array(
		'result' => $result,
		'field' => $field,
		'message' => $message
	);

	echo json_encode( $send );

	mysqli_close( $dbconn );
/*
INSERT INTO `register` (`id`, `nama`, `email`, `password`) VALUES (NULL, 'Bintoro', 'iyut86@yahoo.com', MD5('test'));
*/

<?php

	include_once( 'db_connection.php');

	$txtpass 	= $_POST['txtpassword'];
	$txtemail	= $_POST['txtusername'];

	$result = false;
	$field = "";
	$message = "";

	if( empty( $txtpass ) ){
		$result = false;
		$field = "password";
		$message = "Password is required";
	}else if( empty( $txtemail )){
		$result = false;
		$field = "email";
		$message = "Email is required";
	}else if( !filter_var($txtemail, FILTER_VALIDATE_EMAIL) ){
		$result = false;
		$field = "email";
		$message = "Invalid email format";
	}else{

		$sql = sprintf("SELECT `email`, `password`
				FROM `frm_user`
				WHERE `email` = '%s';"
			, $txtemail
		);

		$dbquery = mysqli_query($dbconn, $sql);

		if( !$dbquery ){

			$result		= false;
			$message	= mysqli_error($dbconn);

		}else{

			if($dbquery == null ){
				$result		= false;
				$field 		= 'email';
				$message	= 'Email is not registered';
			}else{
				while ($row = mysqli_fetch_array($dbquery)) {
					if( md5($txtpass) === $row['password']){
						$result		= true;
						$field 		= 'none';
						$message	= 'Login is successful';
					}else{
						$result		= false;
						$field 		= 'password';
						$message	= 'Password is wrong';
					}
				}
			}
		}
	}

	$send = array(
		'result' => $result,
		'field' => $field,
		'message' => $message
	);

	echo json_encode( $send );

	mysqli_close( $dbconn );
/*
INSERT INTO `register` (`id`, `nama`, `email`, `password`) VALUES (NULL, 'Bintoro', 'iyut86@yahoo.com', MD5('test'));
*/

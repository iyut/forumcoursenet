<html>
	<head></head>

	<body>
		<form method="post" name="frmregister" action="proses_register.php" enctype="multipart/form-data">
			<label>Full Name</label>
			<input type="text" placeholder="Full name" name="txtfullname" value="" />
			<br />

			<label>Email</label>
			<input type="email" placeholder="Email" name="txtemail" value="" />
			<br />

			<label>Password</label>
			<input type="password" placeholder="Password" name="txtpassword" value="" />
			<br />

			<input type="submit" name="submit" />
		</form>
	</body>

</html>

<?php
include_once( 'db_connection.php');

$id = $_GET['threadid'];

$query = sprintf( "select * from frm_comment where thread_id = '%s'", $id);

$dbquery = mysqli_query($dbconn, $query);

if( !$dbquery ){

	$result		= false;
	$message	= mysqli_error();

}else{

	if($dbquery == null ){
		$result		= false;
		$message	= 'No data';
	}else{

		$result = false;
		$datas = array();
		while ($row = mysqli_fetch_array($dbquery)) {

			$datas[] = $row;

			$result = true;
			$message = "Data success";
			
		}
	}
}

$send = array(
	'result' => $result,
	'data' => $datas,
	'message' => $message
);

echo json_encode( $send );

mysqli_close( $dbconn );

<?php
/*
	$usernamesms = 'j8hcaq';
	$passwordsms = 'kingkongprasejarah';
	$notujuan = '081807556285';
	$isisms = urlencode('Thank you for registering the app');

	$urlsms = sprintf('https://reguler.zenziva.net/apps/smsapi.php?userkey=%s&passkey=%s&nohp=%s&pesan=%s',
			$usernamesms,
			$passwordsms,
			$notujuan,
			$isisms
	);

	file_get_contents($urlsms);
*/
	include_once( 'db_connection.php');

	$txttitle 	= $_POST['txttitle'];
	$txtcontent = $_POST['txtcontent'];
	$txtauthor 	= $_POST['txtauthor'];

	// default send value
	$result		= false;
	$field 		= '';
	$message	= '';


	if( empty( $txttitle ) ){
		$result = false;
		$field = "title";
		$message = "Title is required";
	}else if( strlen( $txttitle ) > 200 ){
		$result = false;
		$field = "title";
		$message = "Full name maximum character is 200 Chars";
	}else if( empty( $txtcontent ) ){
		$result = false;
		$field = "content";
		$message = "Content is required";
	}else{

		$sql = sprintf("SELECT *
				FROM `frm_user`
				WHERE `email` = '%s';"
			, $txtauthor
		);

		$dbquery = mysqli_query($dbconn, $sql);

		if( !$dbquery ){

			$result		= false;
			$field 		= 'none';
			$message	= mysqli_error($dbconn);

		}else{

			while ( $row = mysqli_fetch_array( $dbquery ) ) {
		        $id = $row['id'];
		    }

			$sql = sprintf("INSERT INTO `frm_thread` (`title`, `content`, `author`)
						VALUES ('%s', '%s', '%s');",
						$txttitle,
						$txtcontent,
						$id
			);

			$dbquery = mysqli_query($dbconn, $sql);

			if( $dbquery ){

				$result		= true;
				$field 		= 'none';
				$message	= "Your data is saved successfully!";

			}
		}

		

	}

	$send = array(
		'result' => $result,
		'field' => $field,
		'message' => $message
	);

	echo json_encode( $send );

	mysqli_close( $dbconn );
/*
INSERT INTO `register` (`id`, `nama`, `email`, `password`) VALUES (NULL, 'Bintoro', 'iyut86@yahoo.com', MD5('test'));
*/

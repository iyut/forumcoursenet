<?php

$dbconn = mysqli_connect("localhost", 'root', 'pass123qwe', 'project_coursenet_forum');

if(!$dbconn){

	$send = array(
		'result' => false,
		'field' => 'none',
		'message' => "DB is not connected"
	);

	echo json_encode( $send );

	exit();
}

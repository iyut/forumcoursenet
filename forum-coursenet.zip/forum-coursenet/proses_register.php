<?php
/*
	$usernamesms = 'j8hcaq';
	$passwordsms = 'kingkongprasejarah';
	$notujuan = '081807556285';
	$isisms = urlencode('Thank you for registering the app');

	$urlsms = sprintf('https://reguler.zenziva.net/apps/smsapi.php?userkey=%s&passkey=%s&nohp=%s&pesan=%s',
			$usernamesms,
			$passwordsms,
			$notujuan,
			$isisms
	);

	file_get_contents($urlsms);
*/
	include_once( 'db_connection.php');

	$txtname 	= $_POST['txtfullname'];
	$txtpass 	= $_POST['txtpassword'];
	$txtemail	= $_POST['txtemail'];


	// default send value
	$result		= false;
	$field 		= '';
	$message	= '';


	if( empty( $txtname ) ){
		$result = false;
		$field = "fullname";
		$message = "Full name is required";
	}else if( strlen( $txtname ) > 50 ){
		$result = false;
		$field = "fullname";
		$message = "Full name maximum character is 50 Chars";
	}else if( empty( $txtpass ) ){
		$result = false;
		$field = "password";
		$message = "Password is required";
	}else if( empty( $txtemail )){
		$result = false;
		$field = "email";
		$message = "Email is required";
	}else if( strlen( $txtemail ) > 30 ){
		$result = false;
		$field = "email";
		$message = "Email maximum character is 50 Chars";
	}else if( !filter_var($txtemail, FILTER_VALIDATE_EMAIL) ){
		$result = false;
		$field = "email";
		$message = "Invalid email format";
	}else{

		$sql = sprintf("INSERT INTO `frm_user` (`name`, `email`, `password`)
					VALUES ('%s', '%s', MD5('%s'));",
					$txtname,
					$txtemail,
					$txtpass
		);

		$dbquery = mysqli_query($dbconn, $sql);

		if( !$dbquery ){

			$result		= false;
			$field 		= 'none';
			$message	= mysqli_error($dbconn);

			if( strpos($message, "Duplicate entry") !== false ){
				$field 		= 'email';
				$message 	= "Email is registered";

			}
			
		}else{

			$result		= true;
			$field 		= 'none';
			$message	= "Your data is saved successfully!";
		}
	}

	$send = array(
		'result' => $result,
		'field' => $field,
		'message' => $message
	);

	echo json_encode( $send );

	mysqli_close( $dbconn );
/*
INSERT INTO `register` (`id`, `nama`, `email`, `password`) VALUES (NULL, 'Bintoro', 'iyut86@yahoo.com', MD5('test'));
*/

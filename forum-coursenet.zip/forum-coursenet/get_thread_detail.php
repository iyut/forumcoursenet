<?php
	include("db_connection.php");

	$id = $_GET['id'];

	$query = sprintf( "select * from frm_thread where id = '%s'", $id);
	$data = mysqli_query( $dbconn, $query);

	$row = mysqli_fetch_object( $data );

	if( $row != NULL ){

		$result = true;
		$data = $row;
		$message = "Data is retrieved successfully";
	} else {
		$result = false;
		$data = $row;
		$message = "There is no match id";
	}

	$send = array(
		'result' => $result,
		'data' => $data ,
		'message' => $message
	);

	echo json_encode( $send );

mysqli_close( $dbconn );
